Set up asychronous stream processing using pure Python with minimal overhead and no heavyweight systems.


